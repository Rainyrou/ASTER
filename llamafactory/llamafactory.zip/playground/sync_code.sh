#!/bin/bash
# 同步脚本：将指定内容同步到所有远程服务器
set -u

# 检查并安装 sshpass（如果未安装）
if ! command -v sshpass &> /dev/null; then
    echo "检测到 sshpass 未安装，正在尝试安装..."
    if command -v apt-get &> /dev/null; then
        apt-get update -qq && apt-get install -y sshpass 2>&1 | grep -v "^W:" || true
    elif command -v yum &> /dev/null; then
        yum install -y sshpass 2>&1 || true
    else
        echo "错误: 未找到包管理器 (apt-get 或 yum)，无法安装 sshpass"
        echo "请手动安装 sshpass:"
        echo "  Ubuntu/Debian: apt-get install -y sshpass"
        echo "  CentOS/RHEL: yum install -y sshpass"
        exit 1
    fi
    
    # 再次检查是否安装成功
    if ! command -v sshpass &> /dev/null; then
        echo "错误: sshpass 安装失败，请手动安装后重试"
        exit 1
    else
        echo "✓ sshpass 安装成功"
    fi
fi

# 远程服务器列表
remote_ssh_list=(
    "7.216.196.220"
    "7.216.198.25"
    "7.216.199.179"
    "7.216.199.249"
)

# 记录失败和成功的机器
failed_hosts=()
success_hosts=()

# 创建日志目录
LOG_DIR="/root/zhangxq/logs/sync"
mkdir -p "$LOG_DIR"

# 定义同步单个机器的函数
sync_to_machine() {
    local remote_ssh=$1
    local log_file="${LOG_DIR}/${remote_ssh}_sync.log"
    
    # 重定向所有输出到日志文件
    exec > >(tee "$log_file") 2>&1
    
    echo "=========================================="
    echo "正在同步到远程机器: ${remote_ssh}"
    echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "=========================================="
    
    echo "[任务1] 强制同步 llamafactory 目录 (排除 ckpts/* 和 data)..."
    
    local llamafactory_source="/root/zhangxq/llamafactory"
    local llamafactory_dest="/root/zhangxq/"
    
    if [ -d "$llamafactory_source" ]; then
        # 先确保远程目录存在
        SSH_AUTH_SOCK="" sshpass -p 'Hw123456!' ssh -o StrictHostKeyChecking=no root@${remote_ssh} "mkdir -p ${llamafactory_dest}"
        
        # 使用 rsync 同步，排除指定文件/目录，--delete 确保远程与本地一致
        if command -v rsync &> /dev/null; then
            echo "使用 rsync 强制同步 llamafactory 目录..."
            SSH_AUTH_SOCK="" sshpass -p 'Hw123456!' rsync -avz --progress --delete \
                --exclude='ckpts/*' \
                --exclude='data' \
                --exclude='.git' \
                --exclude='__pycache__' \
                --exclude='*.pyc' \
                -e "ssh -o StrictHostKeyChecking=no" \
                "$llamafactory_source" \
                root@${remote_ssh}:${llamafactory_dest}
            
            if [ $? -eq 0 ]; then
                echo "✓ llamafactory 强制同步成功"
            else
                echo "✗ llamafactory 同步失败"
                return 1
            fi
        else
            echo "警告: rsync 未安装，无法精确排除文件"
            echo "建议安装 rsync: apt-get install -y rsync"
            
            # 使用临时目录创建一个不包含排除文件的副本
            echo "创建临时目录进行同步..."
            local temp_dir="/tmp/llamafactory_sync_$$"
            mkdir -p "$temp_dir"
            
            # 使用 tar 排除指定文件
            tar -czf "$temp_dir/llamafactory.tar.gz" \
                -C /root/zhangxq \
                --exclude='ckpts/*' \
                --exclude='data' \
                --exclude='.git' \
                --exclude='__pycache__' \
                --exclude='*.pyc' \
                llamafactory
            
            # 先删除远程的旧目录，确保完全替换
            SSH_AUTH_SOCK="" sshpass -p 'Hw123456!' ssh -o StrictHostKeyChecking=no root@${remote_ssh} "rm -rf /root/zhangxq/llamafactory"
            
            # 传输压缩包
            SSH_AUTH_SOCK="" sshpass -p 'Hw123456!' scp -o StrictHostKeyChecking=no -C \
                "$temp_dir/llamafactory.tar.gz" \
                root@${remote_ssh}:/tmp/
            
            if [ $? -eq 0 ]; then
                # 在远程机器上解压
                SSH_AUTH_SOCK="" sshpass -p 'Hw123456!' ssh -o StrictHostKeyChecking=no root@${remote_ssh} << 'EOF'
                    cd /root/zhangxq
                    tar -xzf /tmp/llamafactory.tar.gz
                    rm -f /tmp/llamafactory.tar.gz
EOF
                echo "✓ llamafactory 强制同步成功"
                
                # 清理临时文件
                rm -rf "$temp_dir"
            else
                echo "✗ llamafactory 同步失败"
                rm -rf "$temp_dir"
                return 1
            fi
        fi
    else
        echo "错误: 本地未找到 $llamafactory_source，无法同步"
        return 1
    fi
    
    echo ""
    
    echo ""
    echo "=========================================="
    echo "远程机器 ${remote_ssh} 同步完成！"
    echo "结束时间: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "=========================================="
    echo ""
    
    return 0
}

# 存储后台进程的 PID
pids=()

# 并行启动所有机器的同步任务
echo "=========================================="
echo "开始并行同步到 ${#remote_ssh_list[@]} 台机器..."
echo "=========================================="
echo ""
echo "同步内容："
echo "  1. /root/zhangxq/llamafactory (排除: ckpts/*, data) - 强制同步"
echo ""

for remote_ssh in ${remote_ssh_list[@]}; do
    echo "启动同步任务: ${remote_ssh} (日志: ${LOG_DIR}/${remote_ssh}_sync.log)"
    sync_to_machine "${remote_ssh}" &
    pids+=($!)
done

echo ""
echo "所有同步任务已启动，等待完成..."
echo "你可以通过以下命令查看实时日志："
echo "  tail -f ${LOG_DIR}/<IP>_sync.log"
echo "  或查看所有日志: tail -f ${LOG_DIR}/*_sync.log"
echo ""

# 等待所有后台任务完成
total=${#pids[@]}
completed=0

for i in "${!pids[@]}"; do
    pid=${pids[$i]}
    remote_ssh=${remote_ssh_list[$i]}
    
    if wait $pid; then
        success_hosts+=("${remote_ssh}")
        completed=$((completed + 1))
        echo "[${completed}/${total}] ${remote_ssh} ✓ 成功"
    else
        failed_hosts+=("${remote_ssh}")
        completed=$((completed + 1))
        echo "[${completed}/${total}] ${remote_ssh} ✗ 失败"
    fi
done

echo ""

echo "=========================================="
echo "同步任务完成！"
echo "=========================================="
echo "总机器数: ${#remote_ssh_list[@]}"
echo "成功: ${#success_hosts[@]} 台"
echo "失败: ${#failed_hosts[@]} 台"
echo ""

if [ ${#success_hosts[@]} -gt 0 ]; then
    echo "✓ 成功的机器列表:"
    for host in "${success_hosts[@]}"; do
        echo "  • ${host} (日志: ${LOG_DIR}/${host}_sync.log)"
    done
    echo ""
fi

if [ ${#failed_hosts[@]} -gt 0 ]; then
    echo "✗ 失败的机器列表:"
    for host in "${failed_hosts[@]}"; do
        echo "  • ${host} (日志: ${LOG_DIR}/${host}_sync.log)"
    done
    echo ""
    echo "请查看失败机器的日志文件以了解详细错误信息"
    exit 1
else
    echo "🎉 所有机器同步成功！"
    echo ""
    echo "日志文件保存在: ${LOG_DIR}/"
    exit 0
fi

