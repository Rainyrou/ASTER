git add .
git commit -m 'empty'
git pull