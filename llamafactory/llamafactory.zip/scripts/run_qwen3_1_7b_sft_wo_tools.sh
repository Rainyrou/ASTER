#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."; pwd)"
DATA_DIR="$ROOT/data"
YAML="$ROOT/examples/train_full/qwen3_1_7b_thinking_wo_tools_sft_full.yaml"

# 启动训练（全参）
log_file="$ROOT/ckpts/train_sft_$(date +%Y%m%d_%H%M%S).log"
time llamafactory-cli train "$YAML" > "$log_file" 2>&1



