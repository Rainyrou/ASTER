#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."; pwd)"
DATA_DIR="$ROOT/data"
YAML="$ROOT/examples/train_full/Open-AgentRL.yaml"

# ============================================
# 配置覆写参数（可以通过以下方式修改，优先级从高到低）：
# 1. 命令行参数：bash run_qwen3_1_7b_sft_full.sh learning_rate=5e-5 num_train_epochs=5
# 2. 环境变量：OVERRIDE_ARGS="learning_rate=5e-5 num_train_epochs=5" bash run_qwen3_1_7b_sft_full.sh
# 3. 脚本内默认值（在下方修改）：
# ============================================
# 在脚本内设置默认覆写参数（取消注释并修改即可）：
# DEFAULT_OVERRIDE_ARGS="learning_rate=5e-5 num_train_epochs=5 output_dir=/path/to/output"

# 合并环境变量和脚本默认值（环境变量优先级更高）
OVERRIDE_ARGS="${OVERRIDE_ARGS:-${DEFAULT_OVERRIDE_ARGS:-}}"

# CONVERTER="$ROOT/scripts/convert_qwen3_thinking_tools.py"
# OUT_FILE="$DATA_DIR/dapo.parquet"

# 可选：转换原始数据
# if [[ ${1-} ]]; then
#   mkdir -p "$DATA_DIR"
#   if command -v uv >/dev/null 2>&1; then
#     uv run "$CONVERTER" "$1" "$OUT_FILE"
#   else
#     python "$CONVERTER" "$1" "$OUT_FILE"
#   fi
# fi

# 启动训练（全参）
# 
# 使用示例：
# 1. 使用默认yaml配置：
#    bash run_qwen3_1_7b_sft_full.sh
#
# 2. 通过命令行参数覆写（推荐，最灵活）：
#    bash run_qwen3_1_7b_sft_full.sh learning_rate=5e-5 num_train_epochs=5
#    bash run_qwen3_1_7b_sft_full.sh cutoff_len=16384 per_device_train_batch_size=2
#
# 3. 通过环境变量覆写（适合批量实验）：
#    OVERRIDE_ARGS="learning_rate=5e-5 num_train_epochs=5" bash run_qwen3_1_7b_sft_full.sh
#
# 4. 混合使用：
#    OVERRIDE_ARGS="learning_rate=5e-5" bash run_qwen3_1_7b_sft_full.sh num_train_epochs=5
#
# 注意：命令行参数会覆写环境变量，环境变量会覆写脚本内默认值

# 合并环境变量和命令行参数
ALL_OVERRIDE_ARGS=()
if [[ -n "$OVERRIDE_ARGS" ]]; then
    # 将环境变量中的参数按空格分割并添加到数组
    read -ra ENV_ARGS <<< "$OVERRIDE_ARGS"
    ALL_OVERRIDE_ARGS+=("${ENV_ARGS[@]}")
fi

# 添加命令行参数（跳过脚本名本身）
if [[ $# -gt 0 ]]; then
    ALL_OVERRIDE_ARGS+=("$@")
fi

mkdir -p "$ROOT/ckpts"
log_file="$ROOT/ckpts/train_Open-AgentRL_$(date +%Y%m%d_%H%M%S).log"

# 构建命令：yaml文件 + 覆写参数
if [[ ${#ALL_OVERRIDE_ARGS[@]} -gt 0 ]]; then
    echo "覆写参数: ${ALL_OVERRIDE_ARGS[*]}"
    time llamafactory-cli train "$YAML" "${ALL_OVERRIDE_ARGS[@]}" > "$log_file" 2>&1
else
    time llamafactory-cli train "$YAML" > "$log_file" 2>&1
fi

# python ./scripts/eval_debug_qwen3_manual.py \
#   --model /root/zhangxq/llamafactory/ckpts/qwen3_1_7b_thinking_Open-AgentRL_full_cutoff_18432_epoch6_bs1_ga4_lr3e-5 \
#   --dataset data/Open-AgentRL.parquet \
#   --num-samples 1 \
#   --max-new-tokens 16484 > eval_debug_qwen3_Open-AgentRL.log 2>&1


