#!/usr/bin/env bash
set -euo pipefail

# Repo root
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.."; pwd)"
DATA_DIR="$ROOT/data"
YAML="$ROOT/examples/train_lora/qwen3_1_7b_thinking_sft.yaml"
CONVERTER="$ROOT/scripts/convert_qwen3_thinking_tools.py"
OUT_FILE="$DATA_DIR/my_qwen3_thinking_tools.parquet"

# Optional: convert raw data to ShareGPT format
if [[ ${1-} ]]; then
  mkdir -p "$DATA_DIR"
  if command -v uv >/dev/null 2>&1; then
    uv run "$CONVERTER" "$1" "$OUT_FILE"
  else
    python "$CONVERTER" "$1" "$OUT_FILE"
  fi
fi

# Launch training
llamafactory-cli train "$YAML"


